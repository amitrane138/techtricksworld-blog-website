<?php
require_once("./../include/config.php");
$c_result= mysqli_query($conn,"SELECT * FROM comment ORDER BY id DESC");
if(mysqli_num_rows($c_result)>0)
{
	while($c_row=mysqli_fetch_assoc($c_result))
	{
		?>
		<div class="card bg-light mb-3" style="max-width: 30rem">
  <div class="card-header"><?php echo $c_row["user"];?></div>
  <div class="card-body">
    <!-- <h5 class="card-title">Info card title</h5> -->
    <p class="card-text"><?php echo $c_row["comment"];?></p>
  </div>
</div>
		<?php
	}
}
?>