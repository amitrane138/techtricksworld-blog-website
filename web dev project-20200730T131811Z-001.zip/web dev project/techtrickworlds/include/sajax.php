<?php
require_once("./../include/config.php");
//Getting value of "search" variable from "script.js".
if (isset($_POST['search'])) {
//Search box value assigning to $Name variable.
   $Name = $_POST['search'];
//Search query.
   $Query = "SELECT id,title FROM blogs WHERE title LIKE '%$Name%' LIMIT 5";
//Query execution
   $ExecQuery =mysqli_query($conn,$Query);

//Creating unordered list to display result.
   //Fetching result from database.
   while ($Result = MySQLi_fetch_ASSOC($ExecQuery)) {
       ?>
   <!-- Creating unordered list items.
        Calling javascript function named as "fill" found in "script.js" file.
        By passing fetched result as parameter. -->
   <li>
   <a href=<?php echo '"temp.php?t='.$Result['title'].'"'?>>
   <!-- Assigning searched result in "Search box" in "search.php" file. -->
       <?php echo $Result['title']; ?>
   </a></li>
   <!-- Below php code is just for closing parenthesis. Don't be confused. -->
   <?php
}}
?>
