      <div class="col-sm-0.5"></div><!--added for space between cols-->
      <div class="col-sm-4 sidenav sidenavblock">
        <!-- <div class="flex-column">
          <form class="form-inline my-2 my-lg-0">
        <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
        <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
      </form>
        </div> -->
        
         <?php
         $sql9="select id,title from blogs";
          $a = array();
         $result9=mysqli_query($conn,$sql9);
         $rowcount=mysqli_num_rows($result9);
         while ($row9=mysqli_fetch_assoc($result9)) {
             array_push($a,$row9["id"]);
         }
         shuffle($a);
         if($rowcount>5)
         {
          $rowcount=5;
         }
         ?> 

        <div class="randompost" >
        <h1>Random post</h1>
        <br>
        <?php 
        for($i=0;$i<$rowcount;$i++)
         {
          ?>
          <p><a href=
           <?php 
          
          $sql2="select title from blogs where id=".$a[$i]."";
          $result=mysqli_query($conn,$sql2);
          $row1=mysqli_fetch_row($result);
          echo '"temp.php?t='.$row1[0].'"';
        ?>>
        <?php
        echo $row1[0];
      }
        ?>
      </a>
        </p>
      </div>
      <div class="recentpost">
        <h1>Recent post</h1>
        <br>
        <?php
          $sql2="select title from blogs limit 8";
        $result=mysqli_query($conn,$sql2);
        while($row3=mysqli_fetch_assoc($result))
        {
          ?>
          <p><a href=
            <?php
              echo '"temp.php?t='.$row3["title"].'"';
            ?>>
        <?php
        echo $row3['title'];
      
        ?>
</a></p><?php }?>
      </div>
      
      </div>
    </div><!--closing row-->    
  <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.2/jquery.min.js"></script>
   <!-- Including our scripting file. -->
   <script type="text/javascript" src="sscript.js"></script>