<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

    <link rel="stylesheet" href="http://use.fontawesome.com/releases/v5.7.0/css/all.css">

    <link rel="stylesheet" type="text/css" href="style.css">

    <link rel="icon" type="image/png" href="ttwicon.png">

    <title>my project</title>
  </head>
  <body>
    <nav class="navbar sticky-top navbar-expand-lg navbar-light bg-light">
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>      Menu
  </button>

  <div class="collapse navbar-collapse nav1" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto" >
      <li class="nav-item">
        <a class="nav-link" href="#"><i class="fas fa-home" style=" font-size:0.9em;margin-left:2px;position:relative;"></i> Home</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#"> Advertise</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#"> About us</a>
      </li>
       <li class="nav-item">
        <a class="nav-link" href="#"> Deals</a>
      </li>
       <li class="nav-item">
        <a class="nav-link" href="#"> Contact us</a>
      </li>
       <li class="nav-item">
        <a class="nav-link" href="#"> Privacy policy</a>
      </li>
      <li class="nav-item active active1">
        <a class="nav-link" href="#"> Blogging resources</a>
      </li>
    </ul>
      <i class="fab fa-twitter" id="twittericon"></i>
      <i class="fab fa-facebook-f" id="facebookicon"></i>
      <i class="fab fa-google-plus-g" id="googleplusicon"></i>
      <i class="fab fa-pinterest" id="pinteresticon"></i>
      <i class="fas fa-rss" id="rssicon"></i>
      
  </div>
</nav>





<div class="container-fluid main_body">
  <img src="ttw.jpg" alt="logo" class="img-fluid"></img>
  <br>
  <br>
  <nav class="navbar pos-f-t navbar-expand-lg navbar-light bg-light nav2">
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarToggleExternalContent" aria-controls="navbarToggleExternalContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span> Browse
    </button>

    <div class="collapse navbar-collapse innernav" id="navbarToggleExternalContent">
      <ul class="navbar-nav mr-auto" >
        <li class="nav-item">
          <a class="nav-link" href="#"> Apps</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#"> Blogging</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#"> Alternatives</a>
        </li>
         <li class="nav-item">
          <a class="nav-link" href="#"> SEO</a>
        </li>
         <li class="nav-item">
          <a class="nav-link" href="#"> Gadgets</a>
        </li>
         <li class="nav-item">
          <a class="nav-link" href="#"> How to</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#"> Software</a>
        </li>
         <li class="nav-item">
          <a class="nav-link" href="#"> Tips & Tricks</a>
        </li>
         <li class="nav-item">
          <a class="nav-link" href="#"> Tools </a>
        </li>
      </ul>
      <form class="form-inline my-2 my-lg-0">
        <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
        <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
      </form>
    </div>
  </nav>

  <div class="container-fluid " >
    <div class="row">
      <div class="col-sm-7 post">
        <p>
          <h1 class="title"> Title</h1>
            <h2>
              hello
              hello
              hello
              hello
              hellohello
              hello
              hello
              hello
              hello
              hellohello
              hello
              hello
              hello
              hello
              hellohello
              hello
              hello
              hello
              hello
              hellohello
              hello
              hello
              hellohello
              hello
              hello
              hello
              hello
              hellohello
              hello
              hello
              hello
              hello
              hellohello
              hello
              hello
              hellohello
              hello
              hello
              hello
              hello
              hellohello
              hello
              hello
              hello
              hello
              hellohello
              hello
              hello
              hellohello
              hello
              hello
              hello
              hello
              hellohello
              hello
              hello
              hello
              hello
              hellohello
              hello
              hello
              hellohello
              hello
              hello
              hello
              hello
              hellohello
              hello
              hello
              hello
              hello
              hellohello
              hello
              hello
              hellohello
              hello
              hello
              hello
              hello
              hellohello
              hello
              hello
              hello
              hello
              hellohello
              hello
              hello


            </h2>
        </p>
      </div>
      <div class="col-sm-0.5"></div><!--added for space between cols-->
      <div class="col-sm-4 sidenav sidenavblock">
        <h1>side bar</h1>
        <p><h2>.post1
         .post2
         .post3
         .post4
        </h2>
        </p>
      
      </div>
    </div><!--closing row-->    
  </div><!--closing post container-->

  
  
  <p><h1>hi hi hi ello
        hellohello
        hello
        hello
        hello
        hello
        hellohello
        hello
        hello
        hello
        hello
        hellohello
        hello
        hello
        hello
        hello
        hellohello
        hello
        hello
</h1></p>



</div><!--end mainbody-->

<footer class="container-fluid">
  <div class="icons">
    <i class="fab fa-twitter" id="twittericon"></i>
    <i class="fab fa-facebook-f" id="facebookicon"></i>
    <i class="fab fa-google-plus-g" id="googleplusicon"></i>
    <i class="fab fa-pinterest" id="pinteresticon"></i>
    <i class="fas fa-rss" id="rssicon"></i>
  </div>  
  <p class="text-responsive">since 2010-2019</p>
</footer>
    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
  </body>
</html>