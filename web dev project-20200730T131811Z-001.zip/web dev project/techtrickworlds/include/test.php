<!DOCTYPE html>
<html>
<body>

<?php
$a=array();
for($i=0;$i<10;$i++)
{

array_push($a,"green");

}
print_r($a);
?>

</body>
</html>
